
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      appBar: AppBar(title: Text('Training Planner')),
      body: Center(child: Text('Добро пожаловать!')),
    ),
  ));
}
